package com.example.helloworldapplication

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_details.*

class DetailsActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        // todo: read data from the previous activity
        if (this.intent != null) {
            var data = this.intent.extras
            var name = data!!.getString("name")

            textView.text = "Welcome "+name.toString()

            // go back to previous activity
            button.setOnClickListener {
                setResult(Activity.RESULT_OK,intent)
                // this is important as you will consume less memory by destroying the current activity
                finish()
            }
        }
    }
}
