package com.example.helloworldapplication.model

class Person {
    var name:String?=null
    var age:Int?=null
}