package com.example.helloworldapplication.data

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.helloworldapplication.DetailsActivity
import com.example.helloworldapplication.R
import com.example.helloworldapplication.model.Person
import android.content.Intent


class PersonListAdapter(
    private val ctx: Context,
    private val list: ArrayList<Person>?
) : RecyclerView.Adapter<PersonListAdapter.ViewHolder>() {

    // inner class
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

        // assign the UI elements the value
        fun bindItem(person: Person) {
            var name: TextView = itemView.findViewById(R.id.name) as TextView
            var age: TextView = itemView.findViewById(R.id.age) as TextView
            //var image: ImageView = itemView.findViewById(R.id.picView) as ImageView

            name.text = person.name
            age.text = person.age.toString()

            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            var name: TextView = itemView.findViewById(R.id.name) as TextView

            // start a new details activity
            var intent = Intent(ctx,DetailsActivity::class.java)
            intent.putExtra("name", name.text.toString())

            ctx.startActivity(intent)
        }
    }

    // create view from list_row
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // create view from xml i.e. list_row using LayoutInflater
        val view = LayoutInflater.from(ctx).inflate(R.layout.list_row, parent, false)

        return ViewHolder(view)
    }

    // return number of items in the list
    override fun getItemCount(): Int {
        return list!!.size
    }

    // bind the view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItem(list!![position])
    }

}