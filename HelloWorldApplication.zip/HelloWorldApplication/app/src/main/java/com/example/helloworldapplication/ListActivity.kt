package com.example.helloworldapplication

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.helloworldapplication.data.PersonListAdapter
import com.example.helloworldapplication.model.Person
import kotlinx.android.synthetic.main.activity_list.*

class ListActivity : AppCompatActivity() {
    var REQUEST_CODE:Int = 1

    private var adapter: PersonListAdapter? = null
    private var personList: ArrayList<Person>? = null
    private var layoutManager: RecyclerView.LayoutManager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        // todo: read data from the previous activity
        if (this.intent != null) {
            var data = this.intent.extras
            var name = data!!.getString("name")

            personList = ArrayList()
            layoutManager = LinearLayoutManager(this)
            adapter = PersonListAdapter(this, personList!!)

            // setup list (Recycler View)
            recyclerView.layoutManager = layoutManager
            recyclerView.adapter = adapter

            when (name) {
                "image_1" -> {
                    // load data
                    generateListFor("name_1 ")
                }
                "image_2" -> {
                    // load data
                    generateListFor("name_2 ")
                }
            }
            // notify adapter for data change
            adapter!!.notifyDataSetChanged()
        }

//        // todo: implementing the go back to previous data
//        button.setOnClickListener {
//                setResult(Activity.RESULT_OK,intent)
//                finish()
//        }
    }

    // generate a list of person
    private fun generateListFor(name: String) {
        for (i in 0..10) {
            var p = Person()
            p.name = name + i
            p.age = 20 + i
            personList!!.add(p)
        }
    }

    // Todo: when you expect something to comeback form the next activity
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//
//        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK){
//            Toast.makeText(this,"I am home", Toast.LENGTH_LONG).show()
//        }
//    }
}
